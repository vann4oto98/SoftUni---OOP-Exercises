package entities;

import entities.interfaces.Tank;

public class TankImpl extends BaseMachine implements Tank {
    private static final double INITIAL_HEALTH = 100;
    private boolean defenceMode = true;
    private double attackPointsModifier = 40.0;
    private double defencePointsModifier = 30.0;

    public TankImpl(String name, double attackPoints, double defencePoints) {
        super(name, attackPoints, defencePoints, INITIAL_HEALTH);
    }

    @Override
    public boolean getDefenseMode() {
        return this.defenceMode;
    }

    @Override
    public void toggleDefenseMode() {
        if (defenceMode){
            this.defenceMode = false;
            super.setAttackPoints(super.getAttackPoints() + this.attackPointsModifier);
            super.setDefensePoints(super.getDefensePoints() - this.defencePointsModifier);
        } else {
            this.defenceMode = true;
            super.setAttackPoints(super.getAttackPoints() - this.attackPointsModifier);
            super.setDefensePoints(super.getDefensePoints() + this.defencePointsModifier);
        }
    }
}
