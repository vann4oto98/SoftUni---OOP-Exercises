package entities;

import entities.interfaces.Fighter;

public class FighterImpl extends BaseMachine implements Fighter {
    private static final double INITIAL_HEALTHPOINTS = 200;
    private boolean aggressiveMode = true;
    private double attackPointsModifier = 50.0;
    private double defencePointsModifier = 25.0;

    public FighterImpl(String name, double attackPoints, double defencePoints) {
        super(name, attackPoints, defencePoints, INITIAL_HEALTHPOINTS);
    }

    @Override
    public boolean getAggressiveMode() {
        return aggressiveMode;
    }

    @Override
    public void toggleAggressiveMode() {
            if (aggressiveMode){
                this.aggressiveMode = false;
                super.setAttackPoints(super.getAttackPoints() - this.attackPointsModifier);
                super.setDefensePoints(super.getDefensePoints() + this.defencePointsModifier);
            } else {
                this.aggressiveMode = true;
                super.setAttackPoints(super.getAttackPoints() + this.attackPointsModifier);
                super.setDefensePoints(super.getDefensePoints() - this.defencePointsModifier);
            }
    }
}
