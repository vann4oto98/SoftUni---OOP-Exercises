package contracts;

public interface Runnable {
	void run();
}
