import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        String[] carInput = sc.nextLine().split("\\s+");
        Vehicle car = new Car(Double.parseDouble(carInput[1]), Double.parseDouble(carInput[2]));
        String[] truckInput = sc.nextLine().split("\\s+");
        Vehicle truck = new Truck(Double.parseDouble(truckInput[1]), Double.parseDouble(truckInput[2]));

        int lines = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < lines; i++) {
            String[] info = sc.nextLine().split("\\s+");
            double value = Double.parseDouble(info[2]);
            if (info[0].equals("Drive")){
                if (info[1].equals("Car")){
                    car.drive(value);
                } else {
                    truck.drive(value);
                }
            } else {
                if (info[1].equals("Car")){
                    car.refuel(value);
                } else {
                    truck.refuel(value);
                }
            }
        }
        System.out.println(car);
        System.out.println(truck);
    }
}
