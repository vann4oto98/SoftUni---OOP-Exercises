import java.text.DecimalFormat;

public class Car extends Vehicle {

 private final double SUMMERCONSUMPTION = 0.9;

    public Car(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);
    }

    @Override
    public void drive(Double distance) {
        if (this.getFuelQuantity() >= (this.getFuelConsumption()+SUMMERCONSUMPTION) * distance){
            System.out.printf("Car travelled %s km%n", new DecimalFormat("#.##").format(distance));
            this.setFuelQuantity(this.getFuelQuantity() - (this.getFuelConsumption()+SUMMERCONSUMPTION) * distance);
        } else {
            System.out.println("Car needs refueling");
        }
    }

    @Override
    public void refuel(Double liters) {
        this.setFuelQuantity(this.getFuelQuantity() + liters);
    }

}
