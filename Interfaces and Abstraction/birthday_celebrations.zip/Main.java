import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);

        List<Birthable> birthables = new ArrayList<>();
        List<Identifiable> identifiables = new ArrayList<>();

        String input = sc.nextLine();
        while (!input.equals("End")){
            String[] info = input.split("\\s+");
            switch (info[0]){
                case "Citizen":
                    birthables.add(new Citizen(info[1], Integer.parseInt(info[2]), info[3], info[4]));
                    identifiables.add(new Citizen(info[1], Integer.parseInt(info[2]), info[3], info[4]));
                    break;
                case "Pet":
                    birthables.add(new Pet(info[1], info[2]));
                    break;
                case "Robot":
                    identifiables.add(new Robot(info[1], info[2]));
                    break;
            }
            input = sc.nextLine();
        }
        String date = sc.nextLine();
        for (Birthable birthable: birthables) {
            if (birthable.getBirthDate().endsWith(date)){
                System.out.println(birthable.getBirthDate());
            }
        }
    }
}
